CREATE TABLE `vehicles` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`year` text NOT NULL,
	`type` text DEFAULT 'sedan' NOT NULL,
	`kilometers` text DEFAULT 'Consultar' NOT NULL,
	`transmission` text DEFAULT 'Consultar' NOT NULL,
	`price` text DEFAULT 'Consultar' NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'available' NOT NULL,
	`cover` text DEFAULT '' NOT NULL,
	`photos` text DEFAULT '[]' NOT NULL,
	`specs` text DEFAULT '[]' NOT NULL,
	`extras` text DEFAULT '[]' NOT NULL,
	`featured` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
