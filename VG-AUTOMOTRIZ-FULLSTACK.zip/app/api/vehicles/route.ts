import { NextResponse } from "next/server";
import { listVehicles } from "@/lib/vehicle-store";

export async function GET() {
  try {
    const vehicles = await listVehicles(false);
    return NextResponse.json({ vehicles }, { headers: { "Cache-Control": "no-store" } });
  } catch (error) {
    console.error("vehicle-list", error);
    return NextResponse.json({ error: "No fue posible cargar el inventario." }, { status: 503 });
  }
}
