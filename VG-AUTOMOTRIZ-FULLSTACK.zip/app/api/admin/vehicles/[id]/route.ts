import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { getVehicle, removeVehicle, saveVehicle } from "@/lib/vehicle-store";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await context.params;
  const vehicle = await getVehicle(id);
  if (!vehicle) return NextResponse.json({ error: "Vehículo no encontrado" }, { status: 404 });
  const updates = await request.json() as Partial<typeof vehicle>;
  const allowed = ["name", "year", "type", "kilometers", "transmission", "price", "description", "status", "featured", "cover", "photos", "extras"] as const;
  for (const key of allowed) {
    if (updates[key] !== undefined) Object.assign(vehicle, { [key]: updates[key] });
  }
  vehicle.updatedAt = Date.now();
  await saveVehicle(vehicle);
  return NextResponse.json({ vehicle });
}

export async function DELETE(_request: Request, context: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  const { id } = await context.params;
  await removeVehicle(id);
  return NextResponse.json({ ok: true });
}
