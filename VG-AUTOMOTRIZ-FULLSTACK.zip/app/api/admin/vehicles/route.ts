import { env } from "cloudflare:workers";
import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-auth";
import { listVehicles, saveVehicle } from "@/lib/vehicle-store";
import type { Vehicle } from "@/lib/vehicle-data";

function slugify(value: string) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 54);
}

async function uploadPhotos(files: File[], id: string) {
  if (!env.BUCKET) throw new Error("El almacenamiento de imágenes no está disponible.");
  const urls: string[] = [];
  for (let index = 0; index < files.length; index++) {
    const file = files[index];
    if (!file.type.startsWith("image/")) continue;
    const extension = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
    const key = `vehicles/${id}/${Date.now()}-${index}.${extension}`;
    await env.BUCKET.put(key, await file.arrayBuffer(), { httpMetadata: { contentType: file.type, cacheControl: "public, max-age=31536000" } });
    urls.push(`/media/${key}`);
  }
  return urls;
}

export async function GET() {
  if (!await requireAdmin()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  return NextResponse.json({ vehicles: await listVehicles(true) });
}

export async function POST(request: Request) {
  if (!await requireAdmin()) return NextResponse.json({ error: "No autorizado" }, { status: 401 });
  try {
    const form = await request.formData();
    const name = String(form.get("name") || "").trim();
    if (!name) return NextResponse.json({ error: "Escribe el nombre del vehículo." }, { status: 400 });
    const id = `${slugify(name)}-${Date.now().toString(36)}`;
    const files = form.getAll("photos").filter((item): item is File => item instanceof File && item.size > 0);
    if (!files.length) return NextResponse.json({ error: "Agrega por lo menos una fotografía." }, { status: 400 });
    const photos = await uploadPhotos(files.slice(0, 12), id);
    const now = Date.now();
    const vehicle: Vehicle = {
      id, name, year: String(form.get("year") || "Consultar"),
      type: String(form.get("type") || "sedan"),
      kilometers: String(form.get("kilometers") || "Consultar"),
      transmission: String(form.get("transmission") || "Consultar"),
      price: String(form.get("price") || "Consultar"),
      description: String(form.get("description") || ""),
      status: "available", cover: photos[0], photos,
      specs: [], extras: String(form.get("extras") || "").split(",").map((v) => v.trim()).filter(Boolean),
      featured: form.get("featured") === "true", createdAt: now, updatedAt: now,
    };
    await saveVehicle(vehicle);
    return NextResponse.json({ vehicle }, { status: 201 });
  } catch (error) {
    console.error("vehicle-create", error);
    return NextResponse.json({ error: error instanceof Error ? error.message : "No fue posible publicar el vehículo." }, { status: 500 });
  }
}
