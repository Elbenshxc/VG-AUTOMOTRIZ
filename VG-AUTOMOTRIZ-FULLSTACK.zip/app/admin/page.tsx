"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { CarFront, Check, Eye, ImagePlus, LogOut, Pencil, Plus, Search, Trash2, X } from "lucide-react";
import type { Vehicle } from "@/lib/vehicle-data";
import styles from "./admin.module.css";

type Mode = "list" | "create" | "edit";

async function resizeImage(file: File) {
  const bitmap = await createImageBitmap(file);
  const max = 1600;
  const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  const blob = await new Promise<Blob>((resolve, reject) => canvas.toBlob((value) => value ? resolve(value) : reject(new Error("No fue posible preparar la imagen.")), "image/webp", .84));
  return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".webp", { type: "image/webp" });
}

export default function AdminPage() {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [mode, setMode] = useState<Mode>("list");
  const [editing, setEditing] = useState<Vehicle | null>(null);
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  const loadVehicles = async () => {
    const response = await fetch("/api/admin/vehicles", { cache: "no-store" });
    if (response.status === 401) { setAuthenticated(false); return; }
    const data = await response.json();
    setVehicles(data.vehicles || []);
    setAuthenticated(true);
  };

  useEffect(() => { loadVehicles().catch(() => setAuthenticated(false)); }, []);

  const filtered = useMemo(() => vehicles.filter((vehicle) => vehicle.name.toLowerCase().includes(query.toLowerCase())), [vehicles, query]);
  const available = vehicles.filter((vehicle) => vehicle.status === "available").length;
  const sold = vehicles.filter((vehicle) => vehicle.status === "sold").length;

  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ username: form.get("username"), password: form.get("password") }) });
    const data = await response.json();
    setBusy(false);
    if (!response.ok) { setMessage(data.error || "No fue posible iniciar sesión."); return; }
    await loadVehicles();
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" }); setAuthenticated(false); setVehicles([]);
  }

  async function createVehicle(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setMessage("Preparando fotografías…");
    const original = new FormData(event.currentTarget);
    const payload = new FormData();
    for (const [key, value] of original.entries()) if (key !== "photos") payload.append(key, value);
    const files = original.getAll("photos").filter((value): value is File => value instanceof File && value.size > 0).slice(0, 12);
    try {
      for (const file of files) payload.append("photos", await resizeImage(file));
      setMessage("Publicando vehículo…");
      const response = await fetch("/api/admin/vehicles", { method: "POST", body: payload });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "No fue posible publicar.");
      await loadVehicles(); setMode("list"); setMessage("Vehículo publicado correctamente.");
    } catch (error) { setMessage(error instanceof Error ? error.message : "No fue posible publicar."); }
    finally { setBusy(false); }
  }

  async function updateVehicle(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); if (!editing) return; setBusy(true); setMessage("");
    const form = new FormData(event.currentTarget);
    const body = Object.fromEntries(form.entries());
    body.featured = form.get("featured") === "true" ? "true" : "false";
    const response = await fetch(`/api/admin/vehicles/${editing.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ ...body, featured: body.featured === "true" }) });
    const data = await response.json(); setBusy(false);
    if (!response.ok) { setMessage(data.error || "No fue posible guardar los cambios."); return; }
    await loadVehicles(); setMode("list"); setEditing(null); setMessage("Cambios guardados.");
  }

  async function setStatus(vehicle: Vehicle, status: Vehicle["status"]) {
    await fetch(`/api/admin/vehicles/${vehicle.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ status }) });
    await loadVehicles();
  }

  async function deleteVehicle(vehicle: Vehicle) {
    if (!confirm(`¿Eliminar definitivamente ${vehicle.name}?`)) return;
    await fetch(`/api/admin/vehicles/${vehicle.id}`, { method: "DELETE" });
    await loadVehicles();
  }

  if (authenticated === null) return <main className={styles.loading}>Cargando panel…</main>;
  if (!authenticated) return <main className={styles.loginPage}><section className={styles.loginCard}><img src="/assets/logo-header.png" alt="VG Automotriz" /><span className={styles.kicker}>PANEL DE INVENTARIO</span><h1>Bienvenido</h1><p>Inicia sesión para actualizar los vehículos publicados.</p><form onSubmit={login}><label>Usuario<input name="username" type="text" placeholder="admin VG automotriz" autoComplete="username" required /></label><label>Contraseña<input name="password" type="password" placeholder="Tu contraseña" autoComplete="current-password" required /></label>{message && <p className={styles.error}>{message}</p>}<button disabled={busy}>{busy ? "Ingresando…" : "Iniciar sesión"}</button></form><a href="/">Volver al catálogo</a></section></main>;

  return <main className={styles.shell}>
    <aside className={styles.sidebar}><img src="/assets/logo-header.png" alt="VG Automotriz" /><nav><button className={mode === "list" ? styles.active : ""} onClick={() => setMode("list")}><CarFront /> Inventario</button><button className={mode === "create" ? styles.active : ""} onClick={() => setMode("create")}><Plus /> Publicar vehículo</button><a href="/" target="_blank"><Eye /> Ver catálogo</a></nav><button className={styles.logout} onClick={logout}><LogOut /> Cerrar sesión</button></aside>

    <section className={styles.workspace}>
      <div className={styles.mobileTop}><img src="/assets/logo-header.png" alt="VG Automotriz" /><button onClick={logout}><LogOut /></button></div>
      {mode === "list" && <><div className={styles.pageHead}><div><span className={styles.kicker}>ADMINISTRACIÓN</span><h1>Inventario</h1><p>Gestiona las unidades que aparecen en la página.</p></div><button className={styles.primary} onClick={() => setMode("create")}><Plus /> Nuevo vehículo</button></div>
        {message && <div className={styles.notice}><Check /> {message}<button onClick={() => setMessage("")}><X /></button></div>}
        <div className={styles.stats}><article><span>Unidades totales</span><strong>{vehicles.length}</strong></article><article><span>Disponibles</span><strong>{available}</strong></article><article><span>Vendidos</span><strong>{sold}</strong></article></div>
        <div className={styles.toolbar}><label><Search /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar por marca o modelo" /></label><span>{filtered.length} resultados</span></div>
        <div className={styles.vehicleList}>{filtered.map((vehicle) => <article className={styles.vehicle} key={vehicle.id}><img src={vehicle.cover || vehicle.photos[0]} alt={vehicle.name} /><div className={styles.vehicleInfo}><span className={`${styles.badge} ${vehicle.status === "sold" ? styles.sold : vehicle.status === "hidden" ? styles.hidden : ""}`}>{vehicle.status === "sold" ? "Vendido" : vehicle.status === "hidden" ? "Oculto" : "Disponible"}</span><h2>{vehicle.name}</h2><p>{vehicle.year} · {vehicle.kilometers} · {vehicle.transmission}</p><strong>{vehicle.price}</strong></div><div className={styles.actions}><button title="Editar" onClick={() => { setEditing(vehicle); setMode("edit"); }}><Pencil /></button>{vehicle.status === "available" ? <button title="Marcar vendido" onClick={() => setStatus(vehicle, "sold")}><Check /></button> : <button title="Volver a publicar" onClick={() => setStatus(vehicle, "available")}><Eye /></button>}<button className={styles.danger} title="Eliminar" onClick={() => deleteVehicle(vehicle)}><Trash2 /></button></div></article>)}</div>
      </>}

      {mode === "create" && <VehicleForm title="Publicar vehículo" subtitle="Las fotografías se optimizan automáticamente antes de subirlas." onSubmit={createVehicle} busy={busy} message={message} onCancel={() => { setMode("list"); setMessage(""); }} />}
      {mode === "edit" && editing && <VehicleForm title="Editar vehículo" subtitle="Actualiza los datos y guarda los cambios." vehicle={editing} onSubmit={updateVehicle} busy={busy} message={message} onCancel={() => { setMode("list"); setEditing(null); setMessage(""); }} />}
    </section>
  </main>;
}

function VehicleForm({ title, subtitle, vehicle, onSubmit, busy, message, onCancel }: { title: string; subtitle: string; vehicle?: Vehicle; onSubmit: (event: FormEvent<HTMLFormElement>) => void; busy: boolean; message: string; onCancel: () => void }) {
  const [previews, setPreviews] = useState<string[]>(vehicle?.photos || []);
  return <><div className={styles.pageHead}><div><span className={styles.kicker}>INVENTARIO</span><h1>{title}</h1><p>{subtitle}</p></div><button className={styles.secondary} onClick={onCancel}><X /> Cancelar</button></div><form className={styles.vehicleForm} onSubmit={onSubmit}><section className={styles.formCard}><h2>Información principal</h2><div className={styles.formGrid}><label className={styles.wide}>Marca y modelo<input name="name" defaultValue={vehicle?.name} placeholder="Ej. Cupra Formentor" required /></label><label>Año<input name="year" defaultValue={vehicle?.year} placeholder="2024" required /></label><label>Tipo<select name="type" defaultValue={vehicle?.type || "suv"}><option value="suv">SUV</option><option value="sedan">Sedán</option><option value="pickup">Pickup</option><option value="hatchback">Hatchback</option><option value="otro">Otro</option></select></label><label>Precio<input name="price" defaultValue={vehicle?.price} placeholder="$600,000" required /></label><label>Kilometraje<input name="kilometers" defaultValue={vehicle?.kilometers} placeholder="4,800 km" required /></label><label>Transmisión<select name="transmission" defaultValue={vehicle?.transmission || "Automática"}><option>Automática</option><option>Manual</option><option>DSG</option><option>Consultar</option></select></label>{vehicle && <label>Estado<select name="status" defaultValue={vehicle.status}><option value="available">Disponible</option><option value="sold">Vendido</option><option value="hidden">Oculto</option></select></label>}<label className={styles.wide}>Descripción<textarea name="description" defaultValue={vehicle?.description} rows={5} placeholder="Describe el estado, equipamiento y características principales…" required /></label><label className={styles.wide}>Extras<input name="extras" defaultValue={vehicle?.extras.join(", ")} placeholder="Único dueño, acepto vehículo, factura original" /></label><label className={styles.check}><input name="featured" value="true" type="checkbox" defaultChecked={vehicle?.featured} /> Mostrar como unidad destacada</label></div></section>{!vehicle && <section className={styles.formCard}><h2>Fotografías</h2><p className={styles.helper}>Selecciona hasta 12 fotografías. La primera será la portada.</p><label className={styles.uploader}><ImagePlus /><strong>Seleccionar fotografías</strong><span>JPG, PNG o WEBP</span><input name="photos" type="file" accept="image/*" multiple required onChange={(event) => { const files = Array.from(event.target.files || []).slice(0, 12); previews.forEach((url) => url.startsWith("blob:") && URL.revokeObjectURL(url)); setPreviews(files.map((file) => URL.createObjectURL(file))); }} /></label>{previews.length > 0 && <div className={styles.previews}>{previews.map((url, index) => <figure key={url}><img src={url} alt={`Vista previa ${index + 1}`} />{index === 0 && <figcaption>Portada</figcaption>}</figure>)}</div>}</section>}<div className={styles.formFooter}>{message && <span>{message}</span>}<button className={styles.primary} disabled={busy}>{busy ? "Guardando…" : vehicle ? "Guardar cambios" : "Publicar vehículo"}</button></div></form></>;
}
