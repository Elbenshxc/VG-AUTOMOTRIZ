"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { LockKeyhole, MapPin, Menu, Search, X } from "lucide-react";
import type { Vehicle } from "@/lib/vehicle-data";
import { initialVehicles } from "@/lib/vehicle-data";

const PHONE = "524491059207";

export function Catalog() {
  const [vehicles, setVehicles] = useState<Vehicle[]>(initialVehicles);
  const [filter, setFilter] = useState("todos");
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState(false);
  const [selected, setSelected] = useState<Vehicle | null>(null);
  const [photo, setPhoto] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState("");

  useEffect(() => {
    fetch("/api/vehicles", { cache: "no-store" })
      .then((response) => response.ok ? response.json() : Promise.reject())
      .then((data) => setVehicles(data.vehicles))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    document.body.classList.toggle("lock", Boolean(selected));
    return () => document.body.classList.remove("lock");
  }, [selected]);

  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.14 });
    const elements = document.querySelectorAll("[data-reveal]");
    elements.forEach((element) => observer.observe(element));
    return () => observer.disconnect();
  }, []);

  const list = useMemo(() => vehicles.filter((vehicle) =>
    (filter === "todos" || vehicle.type === filter)
    && vehicle.name.toLowerCase().includes(query.toLowerCase())
  ), [vehicles, filter, query]);

  const openVehicle = (vehicle: Vehicle) => { setSelected(vehicle); setPhoto(0); };
  const featured = vehicles.find((vehicle) => vehicle.featured && vehicle.status === "available") || vehicles[0];

  async function adminLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoginBusy(true); setLoginError("");
    const form = new FormData(event.currentTarget);
    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ username: form.get("username"), password: form.get("password") }),
    });
    const data = await response.json();
    if (!response.ok) {
      setLoginBusy(false);
      setLoginError(data.error || "No fue posible iniciar sesión.");
      return;
    }
    window.location.href = "/admin";
  }

  return <>
    <link rel="stylesheet" href="/catalog.css" />
    <header className={menuOpen ? "open" : ""}>
      <a className="logo" href="#inicio"><img src="/assets/logo-header.png" alt="VG Automotriz" /></a>
      <nav><a href="#inventario" onClick={() => setMenuOpen(false)}>Inventario</a><a href="#nosotros" onClick={() => setMenuOpen(false)}>Nosotros</a><a href="#contacto" onClick={() => setMenuOpen(false)}>Contacto</a><button className="admin-nav" onClick={() => { setAdminOpen(true); setMenuOpen(false); }}><LockKeyhole size={15} />Acceso administrativo</button></nav>
      <a className="wa-nav" href={`https://wa.me/${PHONE}`} target="_blank" rel="noreferrer"><span className="wa-circle"><img src="/assets/whatsapp.svg" alt="" /></span>WhatsApp</a>
      <button className="menu" aria-label="Abrir menú" onClick={() => setMenuOpen(!menuOpen)}><Menu size={22} /></button>
    </header>

    <main id="inicio">
      <section className="hero"><video className="hero-img" autoPlay muted loop playsInline poster="/assets/cupra-2.jpg"><source src="/assets/hero-cupra.mp4" type="video/mp4" /></video><div className="hero-shade" /><div className="hero-copy"><p className="eyebrow">VG AUTOMOTRIZ · PREMIUM SELECTION</p><h1>MANEJA<br /><em>DIFERENTE.</em></h1><p>Vehículos seleccionados para quienes buscan diseño, rendimiento y una mejor experiencia al volante.</p><a className="gold-btn" href="#inventario">Explorar inventario</a></div>{featured && <button className="hero-car" onClick={() => openVehicle(featured)}><span>UNIDAD DESTACADA</span><strong>{featured.name} {featured.year}</strong><small>Ver ficha</small></button>}</section>

      <section className="inventory" id="inventario">
        <div className="section-title inventory-heading reveal-motion" data-reveal><div><p className="eyebrow">INVENTARIO</p><h2>ENCUENTRA TU PRÓXIMO VEHÍCULO</h2></div><p>Revisa las unidades disponibles y abre cada ficha para consultar fotografías y características.</p></div>
        <div className="catalog-tools reveal-motion" data-reveal><label className="search-box"><Search size={18} /><input value={query} onChange={(event) => setQuery(event.target.value)} type="search" placeholder="Buscar vehículo" aria-label="Buscar vehículo" /></label><select value={filter} onChange={(event) => { setFilter(event.target.value); setExpanded(false); }} aria-label="Filtrar por tipo"><option value="todos">Todos los tipos</option><option value="suv">SUV</option><option value="sedan">Sedán</option><option value="pickup">Pickup</option></select><span>{list.length} vehículos</span></div>
        <div className="grid">{list.slice(0, expanded ? list.length : 8).map((vehicle, index) => <button className={`car card-enter ${vehicle.status === "sold" ? "is-sold" : ""}`} style={{ animationDelay: `${Math.min(index, 11) * 70}ms` }} key={vehicle.id} onClick={() => openVehicle(vehicle)}><span className="car-photo"><img src={vehicle.cover || vehicle.photos[0]} alt={`${vehicle.name} ${vehicle.year}`} loading="lazy" /><span className="status">{vehicle.status === "sold" ? "VENDIDO" : "DISPONIBLE"}</span></span><span className="car-info"><small>{vehicle.year}</small><h3>{vehicle.name}</h3><span className="meta"><span>{vehicle.kilometers}</span><span>{vehicle.transmission}</span></span><strong className="card-price">{vehicle.price}</strong><span className="details-btn">VER DETALLES</span></span></button>)}</div>
        {list.length > 8 && <button className="more" onClick={() => setExpanded(!expanded)}>{expanded ? "Ver menos" : "Ver más vehículos"}</button>}
      </section>

      <section className="about" id="nosotros"><div className="reveal-motion" data-reveal><p className="eyebrow">VG AUTOMOTRIZ</p><h2>EL VEHÍCULO CORRECTO<br />CAMBIA EL CAMINO.</h2></div><div className="reveal-motion reveal-delay" data-reveal><p>Consulta las unidades disponibles, revisa sus características y agenda una visita. Te atendemos directamente para resolver cualquier duda.</p><ul><li><b>01</b> Inventario actualizado</li><li><b>02</b> Atención personalizada</li><li><b>03</b> Ubicación en Aguascalientes</li></ul></div></section>
      <section className="contact" id="contacto"><div className="reveal-motion" data-reveal><p className="eyebrow">CONTACTO</p><h2>CONOCE TU PRÓXIMO AUTO.</h2><p>Av. Aguascalientes Sur #220, esquina Gertrudis Bocanegra, Fracc. Prados del Sur, Aguascalientes, Ags.</p><a href="tel:+524491059207">449 105 9207</a><a href="mailto:jorgevaldez1790@gmail.com">jorgevaldez1790@gmail.com</a><div className="contact-actions"><a className="dark-btn" href={`https://wa.me/${PHONE}`} target="_blank" rel="noreferrer"><span className="wa-circle"><img src="/assets/whatsapp.svg" alt="" /></span>Escribir por WhatsApp</a><a className="line-btn" href="https://www.google.com/maps/search/?api=1&query=Av.+Aguascalientes+Sur+220+Prados+del+Sur+Aguascalientes" target="_blank" rel="noreferrer">Ver ubicación</a></div></div><a className="map reveal-motion reveal-delay" data-reveal href="https://www.google.com/maps/search/?api=1&query=Av.+Aguascalientes+Sur+220+Prados+del+Sur+Aguascalientes" target="_blank" rel="noreferrer"><MapPin size={34} /><div><small>UBICACIÓN</small><strong>Prados del Sur</strong><p>Aguascalientes, México</p></div></a></section>
    </main>

    <footer><div><img src="/assets/logo-header.png" alt="VG Automotriz" /><p>Vehículos seleccionados en Aguascalientes.</p></div><div><b>Navegación</b><a href="#inventario">Inventario</a><a href="#nosotros">Nosotros</a><a href="#contacto">Contacto</a></div><div><b>Redes sociales</b><a className="social-link" href="https://www.facebook.com/vgautomotrizags/" target="_blank" rel="noreferrer"><img src="/assets/facebook.svg" alt="" />Facebook</a><a className="social-link" href="https://www.instagram.com/vg.automotriz" target="_blank" rel="noreferrer"><img src="/assets/instagram.svg" alt="" />Instagram</a><a className="admin-link" href="/admin">Administrar inventario</a></div><small>© 2026 VG Automotriz</small></footer>
    <a className="wa-float" href={`https://wa.me/${PHONE}?text=Hola%2C%20vi%20su%20cat%C3%A1logo%20y%20quiero%20informaci%C3%B3n`} target="_blank" rel="noreferrer" aria-label="Hablar por WhatsApp"><img src="/assets/whatsapp.svg" alt="" /></a>

    {adminOpen && <div className="admin-login-modal" role="dialog" aria-modal="true" aria-labelledby="admin-login-title"><button className="admin-login-overlay" aria-label="Cerrar acceso" onClick={() => setAdminOpen(false)} /><section><button className="admin-login-close" aria-label="Cerrar" onClick={() => setAdminOpen(false)}><X /></button><img src="/assets/logo-header.png" alt="VG Automotriz" /><p className="eyebrow">PANEL DE INVENTARIO</p><h2 id="admin-login-title">Acceso administrativo</h2><p>Ingresa tus datos para administrar los vehículos publicados.</p><form onSubmit={adminLogin}><label>Usuario<input name="username" type="text" placeholder="admin VG automotriz" autoComplete="username" required /></label><label>Contraseña<input name="password" type="password" placeholder="Tu contraseña" autoComplete="current-password" required /></label>{loginError && <span className="admin-login-error">{loginError}</span>}<button type="submit" disabled={loginBusy}>{loginBusy ? "Ingresando…" : "Iniciar sesión"}</button></form></section></div>}

    {selected && <div className="drawer open" aria-hidden="false"><button className="overlay" aria-label="Cerrar" onClick={() => setSelected(null)} /><article role="dialog" aria-modal="true" aria-labelledby="detail-name"><button className="close" aria-label="Cerrar" onClick={() => setSelected(null)}><X /></button><div className="gallery"><img src={selected.photos[photo] || selected.cover} alt={`${selected.name} ${photo + 1}`} />{selected.photos.length > 1 && <><button className="prev" aria-label="Foto anterior" onClick={() => setPhoto((photo - 1 + selected.photos.length) % selected.photos.length)}>‹</button><button className="next" aria-label="Foto siguiente" onClick={() => setPhoto((photo + 1) % selected.photos.length)}>›</button></>}<span>{photo + 1} / {Math.max(selected.photos.length, 1)}</span></div><div className="detail"><p className="eyebrow">{selected.year} · {selected.kilometers}</p><h2 id="detail-name">{selected.name}</h2><strong className="price">{selected.price}</strong><p className="description">{selected.description}</p><h3>ESPECIFICACIONES</h3><div className="specs">{(selected.specs.length ? selected.specs : [["#", "Año", selected.year], ["▦", "Tipo", selected.type.toUpperCase()], ["◴", "Recorrido", selected.kilometers], ["⚙", "Transmisión", selected.transmission], ["◇", "Precio", selected.price], ["▱", "Ubicación", "Aguascalientes"]]).map((spec, index) => <div className="spec" key={index}><i>{spec[0]}</i><small>{spec[1]}</small><strong>{spec[2]}</strong></div>)}</div>{selected.extras.length > 0 && <><h3>EXTRAS</h3><div className="extras">{selected.extras.map((extra) => <span className="extra" key={extra}>{extra}</span>)}</div></>}{selected.status === "sold" ? <p className="sold-note">Esta unidad ya fue vendida.</p> : <a className="detail-wa" href={`https://wa.me/${PHONE}?text=${encodeURIComponent(`Hola, me interesa el ${selected.name} ${selected.year}. ¿Sigue disponible?`)}`} target="_blank" rel="noreferrer"><span className="wa-circle"><img src="/assets/whatsapp.svg" alt="" /></span>Solicitar información</a>}</div></article></div>}
  </>;
}
