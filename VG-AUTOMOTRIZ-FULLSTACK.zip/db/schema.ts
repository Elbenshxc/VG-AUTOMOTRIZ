import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const vehicles = sqliteTable("vehicles", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  year: text("year").notNull(),
  type: text("type").notNull().default("sedan"),
  kilometers: text("kilometers").notNull().default("Consultar"),
  transmission: text("transmission").notNull().default("Consultar"),
  price: text("price").notNull().default("Consultar"),
  description: text("description").notNull().default(""),
  status: text("status").notNull().default("available"),
  cover: text("cover").notNull().default(""),
  photos: text("photos").notNull().default("[]"),
  specs: text("specs").notNull().default("[]"),
  extras: text("extras").notNull().default("[]"),
  featured: integer("featured", { mode: "boolean" }).notNull().default(false),
  createdAt: integer("created_at").notNull(),
  updatedAt: integer("updated_at").notNull(),
});
