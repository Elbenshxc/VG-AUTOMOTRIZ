import { env } from "cloudflare:workers";
import { desc, eq } from "drizzle-orm";
import { getDb } from "@/db";
import { vehicles } from "@/db/schema";
import { initialVehicles, type Vehicle } from "./vehicle-data";

type Row = typeof vehicles.$inferSelect;

function parse<T>(value: string, fallback: T): T {
  try { return JSON.parse(value) as T; } catch { return fallback; }
}

function fromRow(row: Row): Vehicle {
  return {
    id: row.id, name: row.name, year: row.year, type: row.type,
    kilometers: row.kilometers, transmission: row.transmission,
    price: row.price, description: row.description,
    status: row.status as Vehicle["status"], cover: row.cover,
    photos: parse<string[]>(row.photos, []),
    specs: parse<[string, string, string][]>(row.specs, []),
    extras: parse<string[]>(row.extras, []), featured: row.featured,
    createdAt: row.createdAt, updatedAt: row.updatedAt,
  };
}

function toRow(vehicle: Vehicle): typeof vehicles.$inferInsert {
  return {
    ...vehicle,
    photos: JSON.stringify(vehicle.photos),
    specs: JSON.stringify(vehicle.specs),
    extras: JSON.stringify(vehicle.extras),
  };
}

async function seedIfEmpty() {
  const db = getDb();
  const first = await db.select({ id: vehicles.id }).from(vehicles).limit(1);
  if (first.length) return;
  await db.insert(vehicles).values(initialVehicles.map(toRow));
}

export async function listVehicles(includeHidden = false) {
  await seedIfEmpty();
  const rows = await getDb().select().from(vehicles).orderBy(desc(vehicles.featured), desc(vehicles.updatedAt));
  return rows.map(fromRow).filter((v) => includeHidden || v.status !== "hidden");
}

export async function getVehicle(id: string) {
  const row = await getDb().select().from(vehicles).where(eq(vehicles.id, id)).limit(1);
  return row[0] ? fromRow(row[0]) : null;
}

export async function saveVehicle(vehicle: Vehicle) {
  const row = toRow(vehicle);
  await getDb().insert(vehicles).values(row).onConflictDoUpdate({ target: vehicles.id, set: row });
}

export async function removeVehicle(id: string) {
  const existing = await getVehicle(id);
  if (existing && env.BUCKET) {
    const keys = [...existing.photos, existing.cover]
      .filter((url) => url.startsWith("/media/"))
      .map((url) => decodeURIComponent(url.slice("/media/".length)));
    await Promise.all(keys.map((key) => env.BUCKET!.delete(key)));
  }
  await getDb().delete(vehicles).where(eq(vehicles.id, id));
}
