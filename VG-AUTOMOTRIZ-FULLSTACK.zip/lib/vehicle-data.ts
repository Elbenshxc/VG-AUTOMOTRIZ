export type Vehicle = {
  id: string;
  name: string;
  year: string;
  type: string;
  kilometers: string;
  transmission: string;
  price: string;
  description: string;
  status: "available" | "sold" | "hidden";
  cover: string;
  photos: string[];
  specs: [string, string, string][];
  extras: string[];
  featured: boolean;
  createdAt: number;
  updatedAt: number;
};

const now = 1780920000000;

export const initialVehicles: Vehicle[] = [
  {
    id: "cupra",
    name: "Cupra Formentor",
    year: "2024",
    type: "suv",
    kilometers: "4,800 km",
    transmission: "Automática",
    price: "$600,000",
    description: "El Cupra Formentor 2024, con solo 4,800 km y acabado en color blanco, combina diseño deportivo, tecnología y confort. Su interior espacioso incorpora asientos de piel, climatización bi-zona y conectividad pensada para disfrutar cada recorrido.",
    status: "available",
    cover: "/assets/cupra-card.jpg",
    photos: ["/assets/cupra-1.jpg", "/assets/cupra-2.jpg", "/assets/cupra-3.jpg"],
    specs: [["#", "Publicación", "#4774397"], ["◇", "Marca", "Cupra"], ["▱", "Modelo", "Formentor"], ["▦", "Subtipo", "Camioneta SUV"], ["◴", "Recorrido", "4,800 km"], ["≋", "Climatización", "Climatizador bi-zona"], ["⚙", "Tracción", "AWD"], ["◉", "Color", "Blanco"], ["□", "Vidrios", "Eléctricos"], ["⚙", "Transmisión", "Automática"], ["▰", "Tapizado", "Piel"], ["▥", "Combustible", "Gasolina"]],
    extras: ["Acepto vehículo", "Único dueño"],
    featured: true,
    createdAt: now,
    updatedAt: now,
  },
  {
    id: "mercedes",
    name: "Mercedes-Benz CLA",
    year: "Consultar",
    type: "sedan",
    kilometers: "Consultar",
    transmission: "Automática",
    price: "Consultar",
    description: "Mercedes-Benz en color plata. Solicita año, kilometraje, precio y ficha completa directamente con VG Automotriz.",
    status: "available",
    cover: "/assets/catalog-mercedes-v2.jpg",
    photos: ["/assets/mercedes-cla-1.jpg", "/assets/mercedes-cla-2.jpg"],
    specs: [], extras: [], featured: false, createdAt: now - 1, updatedAt: now - 1,
  },
  {
    id: "volvo",
    name: "Volvo EX30",
    year: "2024",
    type: "suv",
    kilometers: "Consultar",
    transmission: "Automática",
    price: "Consultar",
    description: "Galería tomada del material original proporcionado por VG Automotriz. Solicita disponibilidad y ficha completa por WhatsApp.",
    status: "available",
    cover: "/assets/catalog-volvo-v2.jpg",
    photos: ["/assets/volvo-1-clean.jpg", "/assets/volvo-2-clean.jpg"],
    specs: [], extras: [], featured: false, createdAt: now - 2, updatedAt: now - 2,
  },
  {
    id: "taos",
    name: "Volkswagen Taos Highline",
    year: "2023",
    type: "suv",
    kilometers: "70,500 km",
    transmission: "Automática",
    price: "$410,000",
    description: "Volkswagen Taos Highline 2023 en color gris. Consulta equipamiento, condiciones y disponibilidad directamente con VG Automotriz.",
    status: "available",
    cover: "/assets/catalog-taos-v2.jpg",
    photos: ["/assets/taos-1-clean.jpg", "/assets/taos-2-clean.jpg", "/assets/taos-3-clean.jpg"],
    specs: [], extras: [], featured: false, createdAt: now - 3, updatedAt: now - 3,
  },
  {
    id: "corolla",
    name: "Toyota Corolla",
    year: "2024",
    type: "sedan",
    kilometers: "Consultar",
    transmission: "Automática",
    price: "Consultar",
    description: "Toyota Corolla 2024 con galería del material original de la agencia. Solicita precio y ficha completa por WhatsApp.",
    status: "available",
    cover: "/assets/catalog-corolla-v2.jpg",
    photos: ["/assets/corolla-1-clean.jpg", "/assets/corolla-2-clean.jpg", "/assets/corolla-3-clean.jpg"],
    specs: [], extras: [], featured: false, createdAt: now - 4, updatedAt: now - 4,
  },
  {
    id: "frontier",
    name: "Nissan Frontier XE",
    year: "2021",
    type: "pickup",
    kilometers: "152,000 km",
    transmission: "Manual",
    price: "$330,000",
    description: "Nissan Frontier XE 2021 en color blanco. Consulta condiciones, equipamiento y disponibilidad.",
    status: "available",
    cover: "/assets/catalog-frontier-v2.jpg",
    photos: ["/assets/frontier-hd-1.jpg", "/assets/frontier-hd-2.jpg"],
    specs: [], extras: [], featured: false, createdAt: now - 5, updatedAt: now - 5,
  },
];
