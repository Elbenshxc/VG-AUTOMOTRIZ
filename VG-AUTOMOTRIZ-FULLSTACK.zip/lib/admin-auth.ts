import { env } from "cloudflare:workers";
import { cookies } from "next/headers";

const COOKIE = "vg_admin_session";
const encoder = new TextEncoder();

function toBase64(bytes: ArrayBuffer) {
  return btoa(String.fromCharCode(...new Uint8Array(bytes)))
    .replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}

async function sign(value: string) {
  const key = await crypto.subtle.importKey(
    "raw", encoder.encode(env.SESSION_SECRET || "local-vg-session-secret"),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  return toBase64(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}

export async function createSession() {
  const expires = Date.now() + 1000 * 60 * 60 * 12;
  const payload = `admin:${expires}`;
  return `${payload}.${await sign(payload)}`;
}

export async function isValidSession(token?: string) {
  if (!token) return false;
  const split = token.lastIndexOf(".");
  if (split < 0) return false;
  const payload = token.slice(0, split);
  const signature = token.slice(split + 1);
  const [, expires] = payload.split(":");
  if (!expires || Number(expires) < Date.now()) return false;
  return signature === await sign(payload);
}

export async function requireAdmin() {
  const store = await cookies();
  return isValidSession(store.get(COOKIE)?.value);
}

export const sessionCookie = COOKIE;

export function credentialsAreValid(username: string, password: string) {
  return username.trim().toLowerCase() === (env.ADMIN_USERNAME || "admin VG automotriz").toLowerCase()
    && password === (env.ADMIN_PASSWORD || "VG automotriz");
}
